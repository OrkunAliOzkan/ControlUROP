%{
%%  Computing L for observer
p_L = [];
L = place(A22', A12', p_L)'

%%  Computing F, G, H for observer
F = A22 - L*A12;
H = F*L - L*A11 + A21;
G = -L*B1 + B2;
%}

%% Computing K for feedback loop
%{
A = [A11, A12; A21, A22];
B = [B1; B2];
%}

xi    = 0.084;
omega = 3.44;
tao   = 0.03;
mu    = 358.5;

A_2D = [0, 1; -(omega * omega), -2*xi*omega]
B_2D = [0;mu]
C_2D = [1, 0; 0, 1]
%{C_2D = ?%}
    %   2D
        p_K_2D = [-200, -210];
        p_K_3D = [-200, -210, -220];
        p_K_4D = [-200, -210, -220, -230];

K = place(A_2D, B_2D, p_K_2D)